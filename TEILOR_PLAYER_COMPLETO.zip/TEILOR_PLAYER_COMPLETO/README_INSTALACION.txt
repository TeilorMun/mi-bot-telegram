TEILOR PLAYER - INSTALACIÓN

ARCHIVOS:
- bot.py: bot Telegram + API REST del reproductor.
- common.py: base de datos, cifrado, códigos.
- requirements.txt: dependencias Python.
- Procfile: comando de arranque.
- render.yaml: ejemplo de configuración Render con disco persistente.
- Reproductor_TeilOR_ACTIVACION.html: interfaz Android; configurar TEILOR_API_BASE.

1) Reemplaza en GitHub bot.py, common.py y requirements.txt. Añade Procfile. Puedes usar render.yaml como referencia; NO lo despliegues a ciegas si ya tienes un servicio Render configurado.
2) En Render, el servicio debe ser tipo Web Service (no Background Worker). Build: pip install -r requirements.txt. Start: python bot.py.
3) Variables Environment obligatorias:
   TELEGRAM_BOT_TOKEN = token NUEVO de BotFather (nunca dentro del código ni GitHub).
   FERNET_KEY = genera una clave con: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
   ADMIN_IDS = tu ID numérico de Telegram; por defecto se deja el ID que figuraba en tu bot.
   DB_PATH = /var/data/teilor.db si el disco persistente de Render está montado en /var/data.
4) IMPORTANTE: conserva la base de datos anterior. Si el SQLite actual está en otro lugar, antes de cambiar DB_PATH copia el archivo teilor.db al disco persistente /var/data/teilor.db. No cambies FERNET_KEY si quieres descifrar las contraseñas de servidores existentes. La clave anterior del código se generaba al arrancar y no era persistente; los registros cifrados con aquella clave probablemente no se podrán recuperar. Vuelve a introducir esos servidores con /addxtream si no se pueden descifrar.
5) En el HTML, cambia la URL de window.TEILOR_API_BASE a tu dominio HTTPS real de Render, por ejemplo https://NOMBRE.onrender.com (sin barra final). No pongas tokens en HTML.
6) Sube el HTML actualizado al lugar desde el que lo abra la APK/navegador Android. La dirección 127.0.0.1 no sirve como URL pública.
7) En Telegram: /addxtream Nombre | https://servidor | usuario | contraseña. Luego /servidores. Crea un código con /crear 6 1.
8) Pruebas: abre https://TU-SERVICIO.onrender.com/health y debe mostrar status online. Luego activa el HTML con un código.

SEGURIDAD / ALCANCE:
- La API exige sesión para devolver los servidores. Sin embargo, para que el reproductor Xtream funcione directamente en el navegador, el usuario autenticado recibe las credenciales del servidor en su dispositivo; un usuario con acceso puede inspeccionarlas. Para ocultarlas totalmente habría que construir un proxy de streaming/backend, que no forma parte de este parche.
- Esta versión conserva SQLite. Render necesita disco persistente y una sola instancia del servicio. No escales a varias instancias con SQLite. Para varias instancias usa PostgreSQL y adapta common.py.
- Los códigos de activación se guardan y son de un solo uso; los códigos adicionales /vincular se admiten en el mismo campo de activación.
- Los servidores añadidos con /addm3u deben ser enlaces Xtream con usuario y contraseña; el HTML actual no reproduce listas M3U genéricas.
